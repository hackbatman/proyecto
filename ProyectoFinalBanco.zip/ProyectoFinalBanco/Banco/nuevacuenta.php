<?php
//require_once('menu.php');
require_once('conexion.php');

$conn = new Conexion();
$conexion = $conn->Conectar();

      print_r($_POST);
      $cliente = $_POST['cliente'];
      $tipo = $_POST['tipo'];
     $monto = $_POST['monto'];
      

      $query = "insert into cuentas(IDCLIENTE,IDTIPOCUENTA,SALDO)
      values('$cliente','$tipo','$monto')";
      
      $comando = $conexion->prepare($query);
      
      $comando->execute();
      echo $query;
      header('location: menu.php');

    
  



?>