<?php
//require_once('menu.php');
require_once('conexion.php');

//print_r($_POST);

$conn = new Conexion();
$conexion = $conn->Conectar();

      $origen = $_POST['origen'];
      $destino = $_POST['destino'];
      $fecha = $_POST['fecha'];
      $monto = $_POST['monto'];

      $query = "insert into transacciones(IDCUENTAORIGEN,IDCUENTADESTINO,FECHA,MONTO) 
      values('$origen','$destino',TO_DATE('$fecha','YY-MM-DD'),'$monto')";
      
      $comando = $conexion->prepare($query);

      $comando->execute();
      //echo $query;
      header('location: vercuentas.php');

    
  



?>