<?php
require_once('menu.php');
require_once('conexion.php');

$conn = new Conexion();
$conexion = $conn->Conectar();

      $nombre = $_POST['nombre'];
      $dpi = $_POST['dpi'];
      $tel = $_POST['telefono'];
      $email = $_POST['email'];

      $query = "INSERT INTO clientes(NOMBRE, DPI, TELEFONO, EMAIL) VALUES ('$nombre','$dpi','$tel','$email')";
      
      $comando = $conexion->prepare($query);
      
      $comando->execute();
      echo $query;
      header('location: banco_Cliente.php');

    
  



?>